<?php
if (!defined('ABSPATH') && !defined('MCDATAPATH')) exit;

if (!class_exists('MCProtectRuleError_V593')) :
class MCProtectRuleError_V593 extends Exception {
//Root rule error class.
}
endif;
