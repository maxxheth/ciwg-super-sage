<?php
if (!defined('ABSPATH') && !defined('MCDATAPATH')) exit;

require_once dirname( __FILE__ ) . '/lib/utils.php';