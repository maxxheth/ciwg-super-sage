=== SEO One-Click Publishing Plugin ===
Contributors: wordpress
Tags: yoast, rankmath, aioseo, seo, keywords
Requires at least: 4.4
Tested up to: 6.5
Stable tag: 1.4.0
Requires PHP: 5.6
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==
A white-label, one-click SEO publishing plugin designed to streamline content optimization and publishing. It ensures SEO best practices are seamlessly integrated.