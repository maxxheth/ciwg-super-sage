<?php
/**
 * Exception class for the Identity Crisis component.
 *
 * @package  automattic/jetpack-connection
 */

namespace Automattic\Jetpack\IdentityCrisis;

/**
 * Exception class for the Identity Crisis component.
 */
class Exception extends \Exception {}
